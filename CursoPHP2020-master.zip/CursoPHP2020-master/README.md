# CursoPHP2020
Repositório com conteúdo publicados pelos alunos do Curso PHP 2020.

### Material de apoio
O conteúdo a ser estudado pelos alunos está sendo publicado num arquivo OneNote no OneDrive e poderá ser lido no link: https://1drv.ms/u/s!AhIOUkesKPWQjNMwkEPBqdftCKTqgA?e=PNNnyh

Neste material será possível conferir o cronograma das aulas, dicas e conteúdo ensinado.

### SCRUM
Durante o curso, os alunos são capazes de desenvolver um projeto completo utilizando a metodologia ágil SCRUM. Veja o cronograma dos trabalhos em https://trello.com/b/Vd7QJC7r
